//
//  ViewController.m
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//


#import "ltmodel.h"

static NSMutableArray *ltmodellist;

@implementation ltmodel




+ (NSMutableArray *)Instantiation
{
    if (ltmodellist == nil)
    {
        ltmodellist = [[NSMutableArray alloc] init];
        
          NSString *name = @"张三|0,李四|0,王五|0,张四|0,李五|0,王六|0,张五|79,李六|0,王七|0,张三1|79,李四1|79,王五2|79,王五1|79"; //79请假 不参与抽奖
        
        //@"11|0,22|0,33|0,44|0,55|0,66|0,77|0,88|0,99|0,00|0,11|0,222|0,333|0,444|0,555|0,666|0,777|0,888|0,999|0,000|0,1|0,2|0,3|0,4|0,5|0,6|0,7|0,8|100,9|0,0";

           NSArray   *stationArray = [name componentsSeparatedByString:@","];
           NSArray   *_temarray;

             int rowid = 1;
                for(NSString *s in stationArray)
                {
         
                   ltmodel *orderm = [[ltmodel alloc] init];
        
                    _temarray = [s componentsSeparatedByString:@"|"];
                    
                    orderm.name = _temarray[0];
        
                    orderm.ordernum = rowid;
                    //NSString *x =[NSString stringWithFormat:@"%d", arc4random() % 100];

                    orderm.randomnum = arc4random() % 1000;//1;
                    
                    if(_temarray.count > 1)
                    {
                        orderm.state = [_temarray[1] intValue];
                    }
                    else
                    {
                        orderm.state = 0; // 012
                    }

                    rowid ++;
        
                    [ltmodellist addObject:orderm];//]forKey:stationData.stationnamecode];
                    
                }
        
        
    }
    
    return ltmodellist;
}


+ (void) randomnumltlist
{
    if(ltmodellist ==nil)
    {
        [self Instantiation];
        return;
        
    }
    
     for(ltmodel *orderm in ltmodellist)
    {
        orderm.randomnum = arc4random() % 1000;

    }
    
    // 数组对象随机数排序
    [ltmodellist sortUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        
        ltmodel *o1 = obj1;
        ltmodel *o2 = obj2;
        
        float a = o1.randomnum;//(float) [o1.randomnum floatv];
        float b = o2.randomnum;//(float)[o2.randomnum integerValue];
        
        if ( a > b ) {
            return NSOrderedAscending;
        } else if ( a < b ) {
            return NSOrderedDescending;
        } else {
            return NSOrderedSame;
        }
    }];

}



+ (NSArray*) geteffectivelist
{
    //name == 'Herbie'
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"state == %d",0];
    NSArray * result =[[self Instantiation] filteredArrayUsingPredicate:predicate];
    
    return result;
}


+ (NSArray*) getPluslist
{
    //name == 'Herbie'
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"state < %d", 100];
    NSArray * result =[[self Instantiation] filteredArrayUsingPredicate:predicate];
    
    return result;
}


+ (void)updateltmodel:(NSString *)name State:(int)state
{
    //name == 'Herbie'
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name == %@",name];//订单序号
    NSArray * result = [[self Instantiation] filteredArrayUsingPredicate:predicate];
    
    if(result.count > 0)
    {
        ltmodel *ord = result[0];//[self SearchPassenger:OrdModel.ticketdeliverystr famli yname:OrdModel.ticketdeliverystr];
        
        if(ord!=nil)
        {
            
            NSUInteger  indexord =  [ltmodellist indexOfObject:ord];
            
            ltmodel *neword = [[ltmodel alloc] init];
            
            neword.name = ord.name;
            neword.ordernum = ord.ordernum;
            neword.randomnum = ord.randomnum;
            if(state == 100)
            {
                neword.state += state;

            }
            else{
                
                neword.state = state;

            }
            
            [ltmodellist replaceObjectAtIndex:indexord withObject:neword];
            
            
        }
    }
    
}



- (void) encodeWithCoder:(NSCoder *)encoder {
    [encoder encodeObject:self.name forKey:@"name"];
     [encoder encodeObject:[NSNumber numberWithInt:self.ordernum] forKey:@"ordernum"];
    [encoder encodeObject:[NSNumber numberWithInt:self.randomnum] forKey:@"randomnum"];
    [encoder encodeObject:[NSNumber numberWithInt:self.state] forKey:@"state"];

    
    
    
}

- (id)initWithCoder:(NSCoder *)decoder {
    
    self.name  = [decoder decodeObjectForKey:@"name"];
    self.ordernum = (int)[[decoder decodeObjectForKey:@"ordernum"]integerValue];
    self.randomnum = (float)[[decoder decodeObjectForKey:@"randomnum"] floatValue];

    self.state = (int)[[decoder decodeObjectForKey:@"state"]integerValue];
    
    return self;
    
}



 
@end
