//
//  ViewController.m
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//


#import "NSTextFieldPlus.h"

#import <Foundation/NSAffineTransform.h>
#import <QuartzCore/CAAnimation.h>
#import <QuartzCore/CATransaction.h>


@implementation NSTextFieldPlus

-(instancetype)init
{
    self = [super init];
    if (self) {
        //输入框高度
//        NSInteger txtheight = 28;
//        
//        CGRect rect = self.frame;
//        rect.size.height = txtheight;
//        self.frame = rect;
       // self.enabled = false;
    
    }
    return self;
}


- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        
        //输入框高度
//        NSInteger txtheight = 28;
//        
//        CGRect rect = self.frame;
//        rect.size.height = txtheight;
//        self.frame = rect;
        //self.enabled = false;
        
        
     }
    return self;
}



//复写父类的方法
-(BOOL)becomeFirstResponder
{
//    [NSAnimationContext runAnimationGroup:^(NSAnimationContext *context) {
//        [context setDuration:2.0];
//       // float rotation = self.frameRotation;
//        [self valueForKey:@"_displayLabel"].transform = CGAffineTransformMakeTranslation(0, 10);
//self.v
//        [[self animator] setFrameOrigin:NSZeroPoint];
//        [[self animator] setAlphaValue:0.0];
//        //[[animationView animator] setFrameRotation:rotation+360];
//    } completionHandler:^{
//        NSLog(@"All done!");
//    }];

    [self bounceTimeLabel];
    
    
    return [super becomeFirstResponder];
}



- (void)bounceTimeLabel
{
    
    
    NSRect textFieldFrame = [self frame];
    
    CGFloat centerX = textFieldFrame.origin.x;
    CGFloat centerY = textFieldFrame.origin.y;
    
    CABasicAnimation *animation = [[CABasicAnimation alloc] init];
    animation.keyPath = @"position";
    animation.duration = 0.08;
    animation.repeatCount = 2;
    animation.autoreverses = true;
    
    NSPoint one = NSMakePoint(centerX, centerY-2);
    NSPoint two = NSMakePoint(centerX, centerY+2);
    
    animation.fromValue = [NSValue valueWithPoint:one];
    animation.toValue = [NSValue valueWithPoint:two];
    
    [self.layer addAnimation:animation forKey:@"position"];
    
    
   // NSView *content = [[self window] contentView];
//    CALayer *layer = [self layer];
//    
//    CABasicAnimation *anime = [CABasicAnimation animationWithKeyPath:@"backgroundColor"];
//    anime.fromValue = (id)[layer backgroundColor];
//    anime.toValue = (id)CFBridgingRelease(CGColorCreateGenericGray(0.0f, 1.0f));
//    anime.duration = 5.0f;
//    anime.autoreverses = YES;
//    
//    [layer addAnimation:anime forKey:@"backgroundColor"];
//    
//    
//   // [[[self window] contentView] setWantsLayer:YES];
    
    
    
//    
//    // Create a key frame animation
//    CAKeyframeAnimation *bounce =
//    [CAKeyframeAnimation animationWithKeyPath:@"transform"];
//    
//    // Create the values it will pass through
//    CATransform3D forward = CATransform3DMakeScale(1.3, 1.3, 1);
//    CATransform3D back = CATransform3DMakeScale(0.7, 0.7, 1);
//    CATransform3D forward2 = CATransform3DMakeScale(1.2, 1.2, 1);
//    CATransform3D back2 = CATransform3DMakeScale(0.9, 0.9, 1);
//    [bounce setValues:[NSArray arrayWithObjects:
//                       [NSValue valueWithCATransform3D:CATransform3DIdentity],
//                       [NSValue valueWithCATransform3D:forward],
//                       [NSValue valueWithCATransform3D:back],
//                       [NSValue valueWithCATransform3D:forward2],
//                       [NSValue valueWithCATransform3D:back2],
//                       [NSValue valueWithCATransform3D:CATransform3DIdentity],
//                       nil]];
//    // Set the duration
//    [bounce setDuration:0.6];
//    
//    // Animate the layer
//    
//    
//    
//    
//    [[self layer] addAnimation:bounce
//                                        forKey:@"bounceAnimation"];
    
    
    
}

@end
