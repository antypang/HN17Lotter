//
//  ViewController.m
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//

#import "ViewController4.h"
#import <QuartzCore/CAAnimation.h>

#import "NSTextFieldPlus.h"

#import "ltmodel.h"


@implementation ViewController4

int indexnum41;
NSMutableArray *aArray41 ;
NSMutableArray *aArray412 ;
NSMutableArray *aArray413;
NSMutableArray *aArray414 ;

NSMutableArray *aArray416 ;
NSMutableArray *aArray417 ;
NSMutableArray *aArray418 ;
NSMutableArray *aArray419 ;


bool start41;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    start41 = false;
    
    
    aArray41 = [[NSMutableArray alloc] init];
    aArray412 = [[NSMutableArray alloc] init];
    aArray413 = [[NSMutableArray alloc] init];
    aArray414 = [[NSMutableArray alloc] init];
 
    aArray416 = [[NSMutableArray alloc] init];
    aArray417 = [[NSMutableArray alloc] init];
    aArray418 = [[NSMutableArray alloc] init];
    aArray419 = [[NSMutableArray alloc] init];
    
    
    
    
    NSInteger txtheight = 28;
    
    CGRect rect = self.ltten_1.frame;
    rect.size.height = txtheight;
    self.ltten_1.frame = rect;
    self.ltten_1.enabled = false;
    
    CGRect rect2 = self.ltten_2.frame;
    rect2.size.height = txtheight;
    self.ltten_2.frame = rect2;
    self.ltten_2.enabled = false;
    
    CGRect rect3 = self.ltten_3.frame;
    rect3.size.height = txtheight;
    self.ltten_3.frame = rect3;
    self.ltten_3.enabled = false;
    
    CGRect rect4 = self.ltten_4.frame;
    rect4.size.height = txtheight;
    self.ltten_4.frame = rect4;
    self.ltten_4.enabled = false;
    
    
    CGRect rect6 = self.ltten_6.frame;
    rect6.size.height = txtheight;
    self.ltten_6.frame = rect6;
    self.ltten_6.enabled = false;
    
    CGRect rect7 = self.ltten_7.frame;
    rect7.size.height = txtheight;
    self.ltten_7.frame = rect7;
    self.ltten_7.enabled = false;
    
    CGRect rect8 = self.ltten_8.frame;
    rect8.size.height = txtheight;
    self.ltten_8.frame = rect8;
    self.ltten_8.enabled = false;
    
    CGRect rect9 = self.ltten_9.frame;
    rect9.size.height = txtheight;
    self.ltten_9.frame = rect9;
    self.ltten_9.enabled = false;
    
    
    txtheight = 42;
    
    CGRect rect1 = self.btn.frame;
    rect1.size.height = txtheight;
    self.btn.frame = rect1;
    
    
    [ltmodel randomnumltlist];

    // Do any additional setup after loading the view.
}
- (void)controlTextDidChange:(NSNotification *)notification
{
    [self txtTimeLabel:[notification object]];
    
}

//- (void)textDidChange:(NSNotification *)notification
//{
//
//}

- (IBAction)testbtn:(id)sender {
    
    
    
    
    if(start41)
    {
        self.btn.enabled =false;
        self.btn.title =@"本次已抽完";
        start41 = false;
        
        
        [ltmodel updateltmodel:self.ltten_1.stringValue State:4];
        [ltmodel updateltmodel:self.ltten_2.stringValue State:4];
        [ltmodel updateltmodel:self.ltten_3.stringValue State:4];
        [ltmodel updateltmodel:self.ltten_4.stringValue State:4];
        [ltmodel updateltmodel:self.ltten_6.stringValue State:4];
        [ltmodel updateltmodel:self.ltten_7.stringValue State:4];
        [ltmodel updateltmodel:self.ltten_8.stringValue State:4];
        [ltmodel updateltmodel:self.ltten_9.stringValue State:4];
        
        
        NSString *ltstring = @"";
        
        for(ltmodel *_l in [ltmodel Instantiation] )
        {
            ltstring = [ ltstring stringByAppendingFormat:@"%@|%d,",_l.name,_l.state];
        }
        
        // [[ltmodel Instantiation] componentsJoinedByString:@","];
        NSData* ltdata = [ltstring dataUsingEncoding:NSUTF8StringEncoding];
        
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat: @"yyyyMMdd_HHmmss"];
        NSString *fname = [dateFormatter stringFromDate:[NSDate date]];
        
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *strpath = [NSString stringWithFormat:@"%@/ltht%@.txt",NSHomeDirectory(),fname];
        
        bool bRet = [fm createFileAtPath:strpath contents:ltdata attributes:nil];
        
        
        ltstring = [@"" stringByAppendingFormat:@"%@\n%@\n%@\n%@\n%@\n%@\n%@\n%@",self.ltten_1.stringValue,self.ltten_2.stringValue,self.ltten_3.stringValue,self.ltten_4.stringValue ,self.ltten_6.stringValue,self.ltten_7.stringValue,self.ltten_8.stringValue,self.ltten_9.stringValue ];
        
        
        ltdata = [ltstring dataUsingEncoding:NSUTF8StringEncoding];
        
        
        strpath = [NSString stringWithFormat:@"%@/Desktop/四等奖%@.txt",NSHomeDirectory(),fname];
        bRet = [fm createFileAtPath:strpath contents:ltdata attributes:nil];
        
        
        if(!bRet){
            NSLog(@"create file error");
        }
        
        return;
    }
    else
    {
        self.btn.title =@"停止";
        start41 =true;
        
        
    }
    
    if( aArray41 == nil || aArray41.count <1)
    {
        // NSString *name =@"11,22,33,44,55,66,77,88,99,00,11,222,333,444,555,666,777,888,999,000,1,2,3,4,5,6,7,8,9,0";
        // aArray41 = [ltmodel Instantiation];// [name componentsSeparatedByString:@","];
        
        
        
        NSArray * efflist = [ltmodel geteffectivelist];
        
        int listcount = (int)efflist.count;
        
        int agnum = (int)(((float)listcount/8) + 0.4);
        
        //int add = listcount%10;
        
        
        for (int i = 0; i < listcount; i++) {
            
            if(aArray41.count < agnum)
            {
                [aArray41 addObject:efflist[i]];
                
            }
            else if(aArray412.count < agnum)
            {
                [aArray412 addObject:efflist[i]];
                
            }
            else if(aArray413.count < agnum)
            {
                [aArray413 addObject:efflist[i]];
                
            }
            else if(aArray414.count < agnum)
            {
                [aArray414 addObject:efflist[i]];
                
            }
            
            else if(aArray416.count < agnum)
            {
                [aArray416 addObject:efflist[i]];
                
            }
            else if(aArray417.count < agnum)
            {
                [aArray417 addObject:efflist[i]];
                
            }
            else if(aArray418.count < agnum)
            {
                [aArray418 addObject:efflist[i]];
                
            }
            
            else
            {
                [aArray419 addObject:efflist[i]];
                
            }
            
        }
        
        
        
        
        indexnum41 =0;
    }
    
    
    
    //    for(NSString *s in aArray41)
    //    {
    //        //self.ltten_one.stringValue = s;
    //        [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:2];
    //    }
    
    [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:0.05];
    
    
    
    
}

- (void)setlabvale:(NSString*) val {
    
    if(!start41)
    {
        return;
    }
    
    int indext41 = indexnum41;
    
    self.ltten_1.stringValue =  ((ltmodel*)aArray41[indexnum41]).name;
    self.ltten_2.stringValue =  ((ltmodel*)aArray412[indexnum41]).name;
    self.ltten_3.stringValue =  ((ltmodel*)aArray413[indexnum41]).name;
    self.ltten_4.stringValue =  ((ltmodel*)aArray414[indexnum41]).name;

    self.ltten_6.stringValue =  ((ltmodel*)aArray416[indexnum41]).name;
    self.ltten_7.stringValue =  ((ltmodel*)aArray417[indexnum41]).name;
    self.ltten_8.stringValue =  ((ltmodel*)aArray418[indexnum41]).name;
    
    if(indexnum41 >= aArray419.count)
    {
        indext41 = (int)aArray419.count - 1;
    }
    
    self.ltten_9.stringValue = ((ltmodel*)aArray419[indext41]).name;
    
    
    
    indexnum41++;
    
    if(indexnum41 >= aArray41.count)
    {
        indexnum41 = 0;
    }
    
    [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:0.05];
    // Update the view, if already loaded.
}



- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    
    // Update the view, if already loaded.
}




- (void)txtTimeLabel: (NSTextField*)txtfield
{
    
    
    NSRect textFieldFrame = [txtfield frame];
    
    CGFloat centerX = textFieldFrame.origin.x;
    CGFloat centerY = textFieldFrame.origin.y;
    
    CABasicAnimation *animation = [[CABasicAnimation alloc] init];
    animation.keyPath = @"position";
    animation.duration = 0.08;
    animation.repeatCount = 2;
    animation.autoreverses = true;
    
    NSPoint one = NSMakePoint(centerX, centerY-2);
    NSPoint two = NSMakePoint(centerX, centerY+2);
    
    animation.fromValue = [NSValue valueWithPoint:one];
    animation.toValue = [NSValue valueWithPoint:two];
    
    [txtfield.layer addAnimation:animation forKey:@"position"];
}


@end
