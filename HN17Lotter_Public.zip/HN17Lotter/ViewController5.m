//
//  ViewController.m
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//

#import "ViewController5.h"
#import <QuartzCore/CAAnimation.h>

#import "NSTextFieldPlus.h"

#import "ltmodel.h"


@implementation ViewController5



- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    // Do any additional setup after loading the view.
}
- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

 

@end
