//
//  ViewController.m
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//

#import "ViewController1.h"
#import <QuartzCore/CAAnimation.h>

#import "NSTextFieldPlus.h"

#import "ltmodel.h"


@implementation ViewController1

int indexnum11;
NSMutableArray *aArray11 ;


NSMutableArray *aArray119 ;


bool start11;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    start11 = false;
    
    
    aArray11 = [[NSMutableArray alloc] init];
    
    aArray119 = [[NSMutableArray alloc] init];
    
    
    
    
    NSInteger txtheight = 28;
    
    CGRect rect = self.ltten_1.frame;
    rect.size.height = txtheight;
    self.ltten_1.frame = rect;
    self.ltten_1.enabled = false;
    
    
    
    CGRect rect9 = self.ltten_9.frame;
    rect9.size.height = txtheight;
    self.ltten_9.frame = rect9;
    self.ltten_9.enabled = false;
    
    
    
    txtheight = 42;
    
    CGRect rect1 = self.btn.frame;
    rect1.size.height = txtheight;
    self.btn.frame = rect1;
    
    
    // Do any additional setup after loading the view.
}
- (void)controlTextDidChange:(NSNotification *)notification
{
    [self txtTimeLabel:[notification object]];
    
}

//- (void)textDidChange:(NSNotification *)notification
//{
//
//}

- (IBAction)testbtn:(id)sender {
    
    
    
    
    if(start11)
    {
        self.btn.enabled =false;
        self.btn.title =@"本次已抽完";
        start11 = false;
        
        
        [ltmodel updateltmodel:self.ltten_1.stringValue State:3];
  
        [ltmodel updateltmodel:self.ltten_9.stringValue State:4];
        
        
        NSString *ltstring = @"";
        
        for(ltmodel *_l in [ltmodel Instantiation] )
        {
            ltstring = [ ltstring stringByAppendingFormat:@"%@|%d,",_l.name,_l.state];
        }
        
        // [[ltmodel Instantiation] componentsJoinedByString:@","];
        NSData* ltdata = [ltstring dataUsingEncoding:NSUTF8StringEncoding];
        
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat: @"yyyyMMdd_HHmmss"];
        NSString *fname = [dateFormatter stringFromDate:[NSDate date]];
        
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *strpath = [NSString stringWithFormat:@"%@/ltht%@.txt",NSHomeDirectory(),fname];
        
        bool bRet = [fm createFileAtPath:strpath contents:ltdata attributes:nil];
        
        
        ltstring = [@"" stringByAppendingFormat:@"%@\n%@",self.ltten_1.stringValue, self.ltten_9.stringValue ];
        
        
        ltdata = [ltstring dataUsingEncoding:NSUTF8StringEncoding];
        
        
        strpath = [NSString stringWithFormat:@"%@/Desktop/一等奖%@.txt",NSHomeDirectory(),fname];
        bRet = [fm createFileAtPath:strpath contents:ltdata attributes:nil];
        
        
        if(!bRet){
            NSLog(@"create file error");
        }
        
        return;
    }
    else
    {
        self.btn.title =@"停止";
        start11 =true;
        
        
    }
    
    if( aArray11 == nil || aArray11.count <1)
    {
        // NSString *name =@"11,22,33,44,55,66,77,88,99,00,11,222,333,444,555,666,777,888,999,000,1,2,3,4,5,6,7,8,9,0";
        // aArray11 = [ltmodel Instantiation];// [name componentsSeparatedByString:@","];
        
        
        
        NSArray * efflist = [ltmodel geteffectivelist];
        
        int listcount = (int)efflist.count;
        
        int agnum = (int)(((float)listcount/2) + 0.4);
        
        //int add = listcount%10;
        
        
        for (int i = 0; i < listcount; i++) {
            
            if(aArray11.count < agnum)
            {
                [aArray11 addObject:efflist[i]];
                
            }
            else
            {
                [aArray119 addObject:efflist[i]];
                
            }
            
        }
        
        
        
        
        indexnum11 =0;
    }
    
    
    
    //    for(NSString *s in aArray11)
    //    {
    //        //self.ltten_one.stringValue = s;
    //        [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:2];
    //    }
    
    [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:0.05];
    
    
    
    
}

- (void)setlabvale:(NSString*) val {
    
    if(!start11)
    {
        return;
    }
    
    int indext11 = indexnum11;
    
    self.ltten_1.stringValue =  ((ltmodel*)aArray11[indexnum11]).name;
    
    
    if(indexnum11 >= aArray119.count)
    {
        indext11 = (int)aArray119.count - 1;
    }
    
    self.ltten_9.stringValue = ((ltmodel*)aArray119[indext11]).name;
    
    
    indexnum11++;
    
    if(indexnum11 >= aArray11.count)
    {
        indexnum11 = 0;
    }
    
    [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:0.05];
    // Update the view, if already loaded.
}



- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    
    // Update the view, if already loaded.
}




- (void)txtTimeLabel: (NSTextField*)txtfield
{
    
    
    NSRect textFieldFrame = [txtfield frame];
    
    CGFloat centerX = textFieldFrame.origin.x;
    CGFloat centerY = textFieldFrame.origin.y;
    
    CABasicAnimation *animation = [[CABasicAnimation alloc] init];
    animation.keyPath = @"position";
    animation.duration = 0.08;
    animation.repeatCount = 2;
    animation.autoreverses = true;
    
    NSPoint one = NSMakePoint(centerX, centerY-2);
    NSPoint two = NSMakePoint(centerX, centerY+2);
    
    animation.fromValue = [NSValue valueWithPoint:one];
    animation.toValue = [NSValue valueWithPoint:two];
    
    [txtfield.layer addAnimation:animation forKey:@"position"];
}


@end
