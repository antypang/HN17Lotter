//
//  ViewController.m
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//

#import "ViewController.h"
#import <QuartzCore/CAAnimation.h>

#import "NSTextFieldPlus.h"

#import "ltmodel.h"


@implementation ViewController

int indexnum;
NSMutableArray *aArray ;
NSMutableArray *aArray2 ;
NSMutableArray *aArray3;
NSMutableArray *aArray4 ;
NSMutableArray *aArray5 ;

NSMutableArray *aArray6 ;
NSMutableArray *aArray7 ;
NSMutableArray *aArray8 ;
NSMutableArray *aArray9 ;
NSMutableArray *aArray10 ;


bool start;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    start = false;
    
    
    aArray = [[NSMutableArray alloc] init];
    aArray2 = [[NSMutableArray alloc] init];
    aArray3 = [[NSMutableArray alloc] init];
    aArray4 = [[NSMutableArray alloc] init];
    aArray5 = [[NSMutableArray alloc] init];
    aArray6 = [[NSMutableArray alloc] init];
    aArray7 = [[NSMutableArray alloc] init];
    aArray8 = [[NSMutableArray alloc] init];
    aArray9 = [[NSMutableArray alloc] init];
    
    aArray10 = [[NSMutableArray alloc] init];
    
   // NSTextFieldPlus *textF = [[NSTextFieldPlus alloc] init];
   // textF.frame = CGRectMake(60  , 160 , 100, 30);
    
//    [text setBackgroundColor:[NSColor clearColor]];
//    [text setTextColor:[NSColor grayColor]];
//    [text setFocusRingType:1];
//    [text setFont:[NSFont fontWithName:@"Avenir" size:14]];
    
    
    
//    for (int i = 0; i < 2; i++) {
//        
//        
//        for (int j = 0; j < 5; j++) {
//            NSTextFieldPlus *textF = [[NSTextFieldPlus alloc] init];
//            textF.frame = CGRectMake(60 + (j * 100), 160+i * 60, 100, 30);
//            
//            [self.view addSubview:textF];
//        }
//        
//        
//       }

//    self.ltten_1.delegate =self;
//    self.ltten_2.delegate =self;
//    self.ltten_3.delegate =self;
//    self.ltten_4.delegate =self;
//    self.ltten_5.delegate =self;
//    self.ltten_6.delegate =self;
//    self.ltten_7.delegate =self;
//    self.ltten_8.delegate =self;
//    self.ltten_9.delegate =self;
//    self.ltten_10.delegate =self;

    
    
            NSInteger txtheight = 28;
    
            CGRect rect = self.ltten_1.frame;
            rect.size.height = txtheight;
            self.ltten_1.frame = rect;
            self.ltten_1.enabled = false;
    
    CGRect rect2 = self.ltten_2.frame;
    rect2.size.height = txtheight;
    self.ltten_2.frame = rect2;
    self.ltten_2.enabled = false;
    
    CGRect rect3 = self.ltten_3.frame;
    rect3.size.height = txtheight;
    self.ltten_3.frame = rect3;
    self.ltten_3.enabled = false;
    
    CGRect rect4 = self.ltten_4.frame;
    rect4.size.height = txtheight;
    self.ltten_4.frame = rect4;
    self.ltten_4.enabled = false;
    
    CGRect rect5 = self.ltten_5.frame;
    rect5.size.height = txtheight;
    self.ltten_5.frame = rect5;
    self.ltten_5.enabled = false;
    
    CGRect rect6 = self.ltten_6.frame;
    rect6.size.height = txtheight;
    self.ltten_6.frame = rect6;
    self.ltten_6.enabled = false;
    
    CGRect rect7 = self.ltten_7.frame;
    rect7.size.height = txtheight;
    self.ltten_7.frame = rect7;
    self.ltten_7.enabled = false;
    
    CGRect rect8 = self.ltten_8.frame;
    rect8.size.height = txtheight;
    self.ltten_8.frame = rect8;
    self.ltten_8.enabled = false;
    
    CGRect rect9 = self.ltten_9.frame;
    rect9.size.height = txtheight;
    self.ltten_9.frame = rect9;
    self.ltten_9.enabled = false;
    
    CGRect rect10 = self.ltten_10.frame;
    rect10.size.height = txtheight;
    self.ltten_10.frame = rect10;
    self.ltten_10.enabled = false;
    
    
    txtheight = 42;
    
    CGRect rect1 = self.btn.frame;
    rect1.size.height = txtheight;
    self.btn.frame = rect1;
    
    [ltmodel randomnumltlist];

    // Do any additional setup after loading the view.
}
- (void)controlTextDidChange:(NSNotification *)notification
{
    [self txtTimeLabel:[notification object]];
    //
//    
//    if([notification object] == NStextField)
//    {
//        NSLog(@"The contents of the text field changed");
//    }
}

//- (void)textDidChange:(NSNotification *)notification
//{
//    
//}

- (IBAction)testbtn:(id)sender {
    
    
//    
//    
//      testVC=TestingViewController()
//    //同一个Window内，直接替换contentView显示
//    //必须要把下一个ViewController先加到window的contentViewController里，否则其上的按钮事件都会报错
//    self.view.window.contentViewController.addChildViewController(testVC);
//    self.view.window.contentView= testVC.view;
//    
//    //不同Window跳转,同上，必须加入到这个数组内，使用presentXXX的方式，效果有很多
//    //        self.view.window?.contentViewController?.addChildViewController(testVC)
//    //        self.presentViewControllerAsModalWindow(testVC)
//
    
    
    if(start)
    {
        self.btn.enabled =false;
        self.btn.title =@"本次已抽完";
        start = false;
        
        
        [ltmodel updateltmodel:self.ltten_1.stringValue State:5];
        [ltmodel updateltmodel:self.ltten_2.stringValue State:5];
        [ltmodel updateltmodel:self.ltten_3.stringValue State:5];
        [ltmodel updateltmodel:self.ltten_4.stringValue State:5];
        [ltmodel updateltmodel:self.ltten_5.stringValue State:5];
        [ltmodel updateltmodel:self.ltten_6.stringValue State:5];
        [ltmodel updateltmodel:self.ltten_7.stringValue State:5];
        [ltmodel updateltmodel:self.ltten_8.stringValue State:5];
        [ltmodel updateltmodel:self.ltten_9.stringValue State:5];
        [ltmodel updateltmodel:self.ltten_10.stringValue State:5];
        
        
        NSString *ltstring = @"";
        
        for(ltmodel *_l in [ltmodel Instantiation] )
        {
            ltstring = [ ltstring stringByAppendingFormat:@"%@|%d,",_l.name,_l.state];
        }
        
       // [[ltmodel Instantiation] componentsJoinedByString:@","];
        NSData* ltdata = [ltstring dataUsingEncoding:NSUTF8StringEncoding];

        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat: @"yyyyMMdd_HHmmss"];
        NSString *fname = [dateFormatter stringFromDate:[NSDate date]];
        
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *strpath = [NSString stringWithFormat:@"%@/ltht%@.txt",NSHomeDirectory(),fname];
 
        bool bRet = [fm createFileAtPath:strpath contents:ltdata attributes:nil];
        
        
        ltstring = [@"" stringByAppendingFormat:@"%@\n%@\n%@\n%@\n%@\n%@\n%@\n%@\n%@\n%@",self.ltten_1.stringValue,self.ltten_2.stringValue,self.ltten_3.stringValue,self.ltten_4.stringValue,self.ltten_5.stringValue,self.ltten_6.stringValue,self.ltten_7.stringValue,self.ltten_8.stringValue,self.ltten_9.stringValue,self.ltten_10.stringValue];
    
    
        ltdata = [ltstring dataUsingEncoding:NSUTF8StringEncoding];

    
        strpath = [NSString stringWithFormat:@"%@/Desktop/五等奖%@.txt",NSHomeDirectory(),fname];
        bRet = [fm createFileAtPath:strpath contents:ltdata attributes:nil];

        
        if(!bRet){
            NSLog(@"create file error");
        }

        return;
    }
    else
    {
        self.btn.title =@"停止";
        start =true;
       
        
    }

    if( aArray == nil || aArray.count <1)
    {
       // NSString *name =@"11,22,33,44,55,66,77,88,99,00,11,222,333,444,555,666,777,888,999,000,1,2,3,4,5,6,7,8,9,0";
       // aArray = [ltmodel Instantiation];// [name componentsSeparatedByString:@","];
        
        

        NSArray * efflist = [ltmodel geteffectivelist];

        int listcount = (int)efflist.count;
        
        int agnum = (int)(((float)listcount/10) + 0.4);
        
         //int add = listcount%10;
        
        
        for (int i = 0; i < listcount; i++) {
            
            if(aArray.count < agnum)
            {
                [aArray addObject:efflist[i]];

            }
            else if(aArray2.count < agnum)
            {
                  [aArray2 addObject:efflist[i]];

            }
            else if(aArray3.count < agnum)
            {
                [aArray3 addObject:efflist[i]];

            }
            else if(aArray4.count < agnum)
            {
                [aArray4 addObject:efflist[i]];

            }
            else if(aArray5.count < agnum)
            {
                [aArray5 addObject:efflist[i]];

            }
            else if(aArray6.count < agnum)
            {
                [aArray6 addObject:efflist[i]];

            }
            else if(aArray7.count < agnum)
            {
                [aArray7 addObject:efflist[i]];

            }
            else if(aArray8.count < agnum)
            {
                [aArray8 addObject:efflist[i]];

            }
            else if(aArray9.count < agnum)
            {
                [aArray9 addObject:efflist[i]];
            }
            else
            {
                [aArray10 addObject:efflist[i]];

            }
            
        }

        
        
        
        indexnum =0;
    }
    
    
    
//    for(NSString *s in aArray)
//    {
//        //self.ltten_one.stringValue = s;
//        [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:2];
//    }
    
     [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:0.05];
    
    
    

}

- (void)setlabvale:(NSString*) val {
    
    if(!start)
    {
        return;
    }
    
    int indext = indexnum;
   
    self.ltten_1.stringValue =  ((ltmodel*)aArray[indexnum]).name;
    self.ltten_2.stringValue =  ((ltmodel*)aArray2[indexnum]).name;
    self.ltten_3.stringValue =  ((ltmodel*)aArray3[indexnum]).name;
    self.ltten_4.stringValue =  ((ltmodel*)aArray4[indexnum]).name;
    self.ltten_5.stringValue =  ((ltmodel*)aArray5[indexnum]).name;
    self.ltten_6.stringValue =  ((ltmodel*)aArray6[indexnum]).name;
    self.ltten_7.stringValue =  ((ltmodel*)aArray7[indexnum]).name;
    self.ltten_8.stringValue =  ((ltmodel*)aArray8[indexnum]).name;
    self.ltten_9.stringValue =  ((ltmodel*)aArray9[indexnum]).name;
    
    if(indexnum >= aArray10.count)
    {
         indext = (int)aArray10.count - 1;
    }
    
    self.ltten_10.stringValue = ((ltmodel*)aArray10[indext]).name;

    
    
    indexnum++;
    
    if(indexnum >= aArray.count)
    {
       indexnum = 0;
    }
    
     [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:0.05];
    // Update the view, if already loaded.
}



- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}




- (void)txtTimeLabel: (NSTextField*)txtfield
{
    
    
    NSRect textFieldFrame = [txtfield frame];
    
    CGFloat centerX = textFieldFrame.origin.x;
    CGFloat centerY = textFieldFrame.origin.y;
    
    CABasicAnimation *animation = [[CABasicAnimation alloc] init];
    animation.keyPath = @"position";
    animation.duration = 0.08;
    animation.repeatCount = 2;
    animation.autoreverses = true;
    
    NSPoint one = NSMakePoint(centerX, centerY-2);
    NSPoint two = NSMakePoint(centerX, centerY+2);
    
    animation.fromValue = [NSValue valueWithPoint:one];
    animation.toValue = [NSValue valueWithPoint:two];
    
    [txtfield.layer addAnimation:animation forKey:@"position"];
}


@end
