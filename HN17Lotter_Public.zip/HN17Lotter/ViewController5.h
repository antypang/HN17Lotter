//
//  ViewController.h
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//

#import <Cocoa/Cocoa.h>
 

@interface ViewController5 : NSViewController <NSTextFieldDelegate>

 


@end

