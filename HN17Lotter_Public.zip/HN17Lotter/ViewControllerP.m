//
//  ViewConProller.m
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//

#import "ViewControllerP.h"
#import <QuartzCore/CAAnimation.h>

#import "NSTextFieldPlus.h"

#import "ltmodel.h"


@implementation ViewControllerP

int indexnumP;
NSMutableArray *aArrayP ;

NSString *PLKlist;


bool startP;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    startP = false;
    
    self.Plistlable.maximumNumberOfLines = 0;
    PLKlist =@"中奖名单:\n";
    aArrayP = [[NSMutableArray alloc] init];
    
    
    
    NSInteger txtheight = 28;
    
    CGRect rect = self.ltten_9.frame;
    rect.size.height = txtheight;
    self.ltten_9.frame = rect;
    self.ltten_9.enabled = false;
    
    
    txtheight = 42;
    
    CGRect rect1 = self.btn.frame;
    rect1.size.height = txtheight;
    self.btn.frame = rect1;
    
    
    [ltmodel randomnumltlist];
    
    
    // Do any additional setup after loading the view.
}
- (void)controlTextDidChange:(NSNotification *)notification
{
    [self txtTimeLabel:[notification object]];
    
}

//- (void)textDidChange:(NSNotification *)notification
//{
//
//}

- (IBAction)testbtn:(id)sender {
    
    
    
    
    if(startP)
    {
       // self.btn.enabled =false;
        self.btn.title =@"开始";
        startP = false;
        
        
        [ltmodel updateltmodel:self.ltten_9.stringValue State:100];
        PLKlist =[PLKlist stringByAppendingFormat:@"%@\n",  self.ltten_9.stringValue];
 

        self.Plistlable.stringValue = PLKlist;
        
        NSString *ltstring = @"";
        
        for(ltmodel *_l in [ltmodel Instantiation] )
        {
            ltstring = [ltstring stringByAppendingFormat:@"%@|%d,",_l.name,_l.state];
        }
        
        // [[ltmodel Instantiation] componentsJoinedByString:@","];
        NSData* ltdata = [ltstring dataUsingEncoding:NSUTF8StringEncoding];
        
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat: @"yyyyMMdd_HHmmss"];
        NSString *fname = [dateFormatter stringFromDate:[NSDate date]];
        
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *strpath = [NSString stringWithFormat:@"%@/ltht%@.txt",NSHomeDirectory(),fname];
        
        bool bRet = [fm createFileAtPath:strpath contents:ltdata attributes:nil];
        
        ltstring = [@"" stringByAppendingFormat:@"%@",self.ltten_9.stringValue ];
        
        
        ltdata = [ltstring dataUsingEncoding:NSUTF8StringEncoding];
        
        
        strpath = [NSString stringWithFormat:@"%@/Desktop/加等奖%@.txt",NSHomeDirectory(),fname];
        bRet = [fm createFileAtPath:strpath contents:ltdata attributes:nil];
        
        
        if(!bRet){
            NSLog(@"create file error");
        }
        
        return;
    }
    else
    {
        self.btn.title =@"停止";
        startP =true;
        
        
    }
    
//    if( aArrayP == nil || aArrayP.count <1)
//    {
//        // NSString *name =@"11,22,33,44,55,66,77,88,99,00,11,222,333,444,555,666,777,888,999,000,1,2,3,4,5,6,7,8,9,0";
        // aArrayP = [ltmodel Instantiation];// [name componentsSeparatedByString:@","];
        
       [ltmodel randomnumltlist]; 
        
        NSArray * efflist = [ltmodel geteffectivelist];
        
        int listcount = (int)efflist.count;
        
        //int agnum = (int)(((float)listcount/3) + 0.4);
        
        //int add = listcount%10;
        
        for (int i = 0; i < listcount; i++) {
            
            //            if(aArrayP.count < agnum)
            //            {
            [aArrayP addObject:efflist[i]];
            
            //            }
            
            
        }
        
        
        
        
//        indexnumP =0;
//    }
    
    
    
    //    for(NSString *s in aArrayP)
    //    {
    //        //self.ltten_one.stringValue = s;
    //        [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:2];
    //    }
    
    [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:0.05];
    
    
    
    
}

- (void)setlabvale:(NSString*) val {
    
    if(!startP)
    {
        return;
    }
    
    
    self.ltten_9.stringValue =  ((ltmodel*)aArrayP[indexnumP]).name;
    
    
    indexnumP++;
    
    if(indexnumP >= aArrayP.count)
    {
        indexnumP = 0;
    }
    
    [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:0.05];
    // Update the view, if already loaded.
}



- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    
    // Update the view, if already loaded.
}




- (void)txtTimeLabel: (NSTextField*)txtfield
{
    
    
    NSRect textFieldFrame = [txtfield frame];
    
    CGFloat centerX = textFieldFrame.origin.x;
    CGFloat centerY = textFieldFrame.origin.y;
    
    CABasicAnimation *animation = [[CABasicAnimation alloc] init];
    animation.keyPath = @"position";
    animation.duration = 0.08;
    animation.repeatCount = 2;
    animation.autoreverses = true;
    
    NSPoint one = NSMakePoint(centerX, centerY-2);
    NSPoint two = NSMakePoint(centerX, centerY+2);
    
    animation.fromValue = [NSValue valueWithPoint:one];
    animation.toValue = [NSValue valueWithPoint:two];
    
    [txtfield.layer addAnimation:animation forKey:@"position"];
}


@end
