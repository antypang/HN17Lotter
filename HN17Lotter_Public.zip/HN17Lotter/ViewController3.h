//
//  ViewController.h
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//

#import <Cocoa/Cocoa.h>
 

@interface ViewController3 : NSViewController <NSTextFieldDelegate>
 


@property (weak) IBOutlet NSTextField *ltten_1;
@property (weak) IBOutlet NSTextField *ltten_2;
@property (weak) IBOutlet NSTextField *ltten_3;
@property (weak) IBOutlet NSTextField *ltten_4;
 
@property (weak) IBOutlet NSTextField *ltten_9;


@property (weak) IBOutlet NSButton *btn;




@end

