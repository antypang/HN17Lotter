//
//  ViewController.m
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//

#import "ViewController2.h"
#import <QuartzCore/CAAnimation.h>

#import "NSTextFieldPlus.h"

#import "ltmodel.h"


@implementation ViewController2

int indexnum21;
NSMutableArray *aArray21 ;
NSMutableArray *aArray212 ;


NSMutableArray *aArray219 ;


bool start21;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    start21 = false;
    
    
    aArray21 = [[NSMutableArray alloc] init];
    aArray212 = [[NSMutableArray alloc] init];
    
    aArray219 = [[NSMutableArray alloc] init];
    
    
    
    
    NSInteger txtheight = 28;
    
    CGRect rect = self.ltten_1.frame;
    rect.size.height = txtheight;
    self.ltten_1.frame = rect;
    self.ltten_1.enabled = false;
    
    CGRect rect2 = self.ltten_2.frame;
    rect2.size.height = txtheight;
    self.ltten_2.frame = rect2;
    self.ltten_2.enabled = false;
    
    
    CGRect rect9 = self.ltten_9.frame;
    rect9.size.height = txtheight;
    self.ltten_9.frame = rect9;
    self.ltten_9.enabled = false;
    
    
    txtheight = 42;
    
    CGRect rect1 = self.btn.frame;
    rect1.size.height = txtheight;
    self.btn.frame = rect1;
    
    
    [ltmodel randomnumltlist];

    
    
    // Do any additional setup after loading the view.
}
- (void)controlTextDidChange:(NSNotification *)notification
{
    [self txtTimeLabel:[notification object]];
    
}

//- (void)textDidChange:(NSNotification *)notification
//{
//
//}

- (IBAction)testbtn:(id)sender {
    
    
    
    
    if(start21)
    {
        self.btn.enabled =false;
        self.btn.title =@"本次已抽完";
        start21 = false;
        
        
        [ltmodel updateltmodel:self.ltten_1.stringValue State:3];
        [ltmodel updateltmodel:self.ltten_2.stringValue State:3];
 
        [ltmodel updateltmodel:self.ltten_9.stringValue State:4];
        
        
        NSString *ltstring = @"";
        
        for(ltmodel *_l in [ltmodel Instantiation] )
        {
            ltstring = [ ltstring stringByAppendingFormat:@"%@|%d,",_l.name,_l.state];
        }
        
        // [[ltmodel Instantiation] componentsJoinedByString:@","];
        NSData* ltdata = [ltstring dataUsingEncoding:NSUTF8StringEncoding];
        
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat: @"yyyyMMdd_HHmmss"];
        NSString *fname = [dateFormatter stringFromDate:[NSDate date]];
        
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *strpath = [NSString stringWithFormat:@"%@/ltht%@.txt",NSHomeDirectory(),fname];
        
        bool bRet = [fm createFileAtPath:strpath contents:ltdata attributes:nil];
        
        
        ltstring = [@"" stringByAppendingFormat:@"%@\n%@\n%@",self.ltten_1.stringValue,self.ltten_2.stringValue,self.ltten_9.stringValue ];
        
        
        ltdata = [ltstring dataUsingEncoding:NSUTF8StringEncoding];
        
        
        strpath = [NSString stringWithFormat:@"%@/Desktop/二等奖%@.txt",NSHomeDirectory(),fname];
        bRet = [fm createFileAtPath:strpath contents:ltdata attributes:nil];
        
        
        if(!bRet){
            NSLog(@"create file error");
        }
        
        return;
    }
    else
    {
        self.btn.title =@"停止";
        start21 =true;
        
        
    }
    
    if( aArray21 == nil || aArray21.count <1)
    {
        // NSString *name =@"11,22,33,44,55,66,77,88,99,00,11,222,333,444,555,666,777,888,999,000,1,2,3,4,5,6,7,8,9,0";
        // aArray21 = [ltmodel Instantiation];// [name componentsSeparatedByString:@","];
        
        
        
        NSArray * efflist = [ltmodel geteffectivelist];
        
        int listcount = (int)efflist.count;
        
        int agnum = (int)(((float)listcount/3) + 0.4);
        
        //int add = listcount%10;
        
        
        for (int i = 0; i < listcount; i++) {
            
            if(aArray21.count < agnum)
            {
                [aArray21 addObject:efflist[i]];
                
            }
            else if(aArray212.count < agnum)
            {
                [aArray212 addObject:efflist[i]];
                
            }
           
            
            else
            {
                [aArray219 addObject:efflist[i]];
                
            }
            
        }
        
        
        
        
        indexnum21 =0;
    }
    
    
    
    //    for(NSString *s in aArray21)
    //    {
    //        //self.ltten_one.stringValue = s;
    //        [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:2];
    //    }
    
    [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:0.05];
    
    
    
    
}

- (void)setlabvale:(NSString*) val {
    
    if(!start21)
    {
        return;
    }
    
    int indext21 = indexnum21;
    
    self.ltten_1.stringValue =  ((ltmodel*)aArray21[indexnum21]).name;
    self.ltten_2.stringValue =  ((ltmodel*)aArray212[indexnum21]).name;
    
    
    if(indexnum21 >= aArray219.count)
    {
        indext21 = (int)aArray219.count - 1;
    }
    
    self.ltten_9.stringValue = ((ltmodel*)aArray219[indext21]).name;
    
    
    indexnum21++;
    
    if(indexnum21 >= aArray21.count)
    {
        indexnum21 = 0;
    }
    
    [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:0.05];
    // Update the view, if already loaded.
}



- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    
    // Update the view, if already loaded.
}




- (void)txtTimeLabel: (NSTextField*)txtfield
{
    
    
    NSRect textFieldFrame = [txtfield frame];
    
    CGFloat centerX = textFieldFrame.origin.x;
    CGFloat centerY = textFieldFrame.origin.y;
    
    CABasicAnimation *animation = [[CABasicAnimation alloc] init];
    animation.keyPath = @"position";
    animation.duration = 0.08;
    animation.repeatCount = 2;
    animation.autoreverses = true;
    
    NSPoint one = NSMakePoint(centerX, centerY-2);
    NSPoint two = NSMakePoint(centerX, centerY+2);
    
    animation.fromValue = [NSValue valueWithPoint:one];
    animation.toValue = [NSValue valueWithPoint:two];
    
    [txtfield.layer addAnimation:animation forKey:@"position"];
}


@end
