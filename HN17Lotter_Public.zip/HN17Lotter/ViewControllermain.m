//
//  ViewController.m
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//

#import "ViewControllermain.h"


NSView *fivelttempview;

@implementation ViewControllermain


- (void)viewDidLoad {
    [super viewDidLoad];
    
//    NSImage *image=[NSImage imageNamed:@"2016HN.png"];
//
//    
//    [image drawInRect:NSMakeRect(0, 0, self.view.frame.size.width, self.view.frame.size.height)
//             fromRect:NSZeroRect
//             operation:NSCompositeSourceOver
//             fraction:1];
    
    self.fiveltswith.hidden = true;
    
   

    
    //self.view.title = @"海纳国旅17年红红火火抽大奖";
    // Do any additional setup after loading the view.
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

- (IBAction)fiveltbtn:(id)sender {
    
    
    self.fiveltswith.hidden = false;
    
//    if (self.ViewController1 == nil)
//    {
//        
//        self.ViewController1 = [self.storyboard instantiateControllerWithIdentifier: @"ViewController2"];
//    }
//  
//    
//    
//    [self.myTargetView addSubview:[self.ViewController1 view]];
    
 
    
}

- (IBAction)fourltbtn:(id)sender {
    
    self.fiveltswith.hidden = true;

    
        if (self.ViewController41 == nil)
        {
    
            self.ViewController41 = [self.storyboard instantiateControllerWithIdentifier: @"ViewController41"];
        }
    
    NSView *NV =[self.ViewController41 view] ;
    [self ShowTargetView:NV];

    
    
}
- (IBAction)threeltbtn:(id)sender {
    
    self.fiveltswith.hidden = true;

    
    if (self.ViewController31 == nil)
    {
        
        self.ViewController31 = [self.storyboard instantiateControllerWithIdentifier: @"ViewController31"];
    }
    
    NSView *NV =[self.ViewController31 view] ;
    [self ShowTargetView:NV];
}
- (IBAction)twoltbtn:(id)sender {
    
    self.fiveltswith.hidden = true;

    
    if (self.ViewController21 == nil)
    {
        
        self.ViewController21 = [self.storyboard instantiateControllerWithIdentifier: @"ViewController21"];
    }
    
    NSView *NV =[self.ViewController21 view] ;
    [self ShowTargetView:NV];
}

- (IBAction)oneltbtn:(id)sender {
    
    self.fiveltswith.hidden = true;

    
    if (self.ViewController11 == nil)
    {
        
        self.ViewController11 = [self.storyboard instantiateControllerWithIdentifier: @"ViewController11"];
    }
    
    NSView *NV =[self.ViewController11 view] ;
    [self ShowTargetView:NV];
    
}
- (IBAction)superltbtn:(id)sender {
    
    
    self.fiveltswith.hidden = true;

    if (self.ViewControllerT == nil)
    {
        
        self.ViewControllerT = [self.storyboard instantiateControllerWithIdentifier: @"ViewControllerT"];
    }
    
    NSView *NV =[self.ViewControllerT view] ;
    [self ShowTargetView:NV];
}
- (IBAction)plusltbtn:(id)sender {
    
    
    self.fiveltswith.hidden = true;

    if (self.ViewControllerP == nil)
    {
        
        self.ViewControllerP = [self.storyboard instantiateControllerWithIdentifier: @"ViewControllerP"];
    }
    
    NSView *NV =[self.ViewControllerP view] ;
    [self ShowTargetView:NV];
    
}


- (IBAction)fiveltsegmented:(id)sender {
    
    NSSegmentedCell *nsc = (NSSegmentedCell*) sender;
    
    NSView *NV ;
    
    
    switch(nsc.selectedSegment+1)
    {
            
            case 1:
            
            
            if (self.ViewController1 == nil)
            {
                
                self.ViewController1 = [self.storyboard instantiateControllerWithIdentifier: @"ViewController1"];
            }
            
            NV = [self.ViewController1 view];
            
            break;
            case 2:
            
            if (self.ViewController2 == nil)
            {
                
                self.ViewController2 = [self.storyboard instantiateControllerWithIdentifier: @"ViewController2"];
            }
            
            NV = [self.ViewController2 view];
            break;
        case 3:
            
            if (self.ViewController3 == nil)
            {
                
                self.ViewController3 = [self.storyboard instantiateControllerWithIdentifier: @"ViewController3"];

            }
            NV = [self.ViewController3 view];
            
            
            break;

        case 4:
            
            if (self.ViewController4 == nil)
            {
                
                self.ViewController4 = [self.storyboard instantiateControllerWithIdentifier: @"ViewController4"];
            }
            
            NV = [self.ViewController4 view];
            break;

        case 5:
            
            if (self.ViewController5 == nil)
            {
                
                self.ViewController5 = [self.storyboard instantiateControllerWithIdentifier: @"ViewController5"];
            }
            
            NV = [self.ViewController5 view];
            break;

            default:
            break;
            
    }
    
  
//     
//    if(NV==nil)
//    {
//        [self.myTargetView viewWithTag:nsc.selectedSegment + 1].hidden = false;
//
//    }
//    else{
    
    
    
    [self ShowTargetView:NV];
    
    
}




-(void)ShowTargetView :(NSView*)ShowView
{
    
    
    if(fivelttempview == ShowView)
    {
        return;
    }
    
    
    [self.myTargetView addSubview:ShowView ];
    
    
    [fivelttempview removeFromSuperview];
    
    fivelttempview = ShowView;

    
}




@end
