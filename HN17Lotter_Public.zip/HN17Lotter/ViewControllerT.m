//
//  ViewController.m
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//

#import "ViewControllerT.h"
//#import <QuartzCore/CAAnimation.h>


#import "ltmodel.h"


@implementation ViewControllerT

int indexnumT;
NSMutableArray *aArrayT ;

CABasicAnimation *animation ;

bool startT;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    startT = false;
    

    aArrayT = [[NSMutableArray alloc] init];
    
    
    NSInteger txtheight = 28;
    
    CGRect rect = self.ltten_1.frame;
    rect.size.height = txtheight;
    self.ltten_1.frame = rect;
    self.ltten_1.enabled = false;
    
    
//    CGRect rect2 = self.lthdbtn.frame;
//    rect2.size.height = 48;
//    self.lthdbtn.frame = rect2;
//    self.lthdbtn.hidden = true;
    
    
    txtheight = 42;
    
    CGRect rect1 = self.btn.frame;
    rect1.size.height = txtheight;
    self.btn.frame = rect1;
    
    [ltmodel randomnumltlist];
    
    
  

    
    // Do any additional setup after loading the view.
}


//- (IBAction)dohide:(id)sender {
//    
//    NSButton * btn =(NSButton*) sender;
//    animation = [CABasicAnimation animationWithKeyPath:@"opacity"];
//    animation.delegate = self;
//    animation.duration = 3.0;
//    animation.autoreverses = NO;
//    animation.repeatCount = 1;
//    animation.fromValue = [NSNumber numberWithFloat:1];
//    animation.toValue = [NSNumber numberWithFloat:0];
//    [btn.layer addAnimation:animation forKey:@""];
//
//}


//
//- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
//{
//    
//    self.lthdbtn.hidden = true;
//    
//}





- (void)controlTextDidChange:(NSNotification *)notification
{
    [self txtTimeLabel:[notification object]];
    
}

//- (void)textDidChange:(NSNotification *)notification
//{
//
//}

- (IBAction)testbtn:(id)sender {
    
    
    if(startT)
    {
//        self.lthdbtn.hidden = false;
        
        self.btn.enabled =false;
        self.btn.title =@"本次已抽完";
        startT = false;
        
        
        [ltmodel updateltmodel:self.ltten_1.stringValue State:8];
        
        
        NSString *ltstring = @"";
        
        for(ltmodel *_l in [ltmodel Instantiation] )
        {
            ltstring = [ ltstring stringByAppendingFormat:@"%@|%d,",_l.name,_l.state];
        }
        
        // [[ltmodel Instantiation] componentsJoinedByString:@","];
        NSData* ltdata = [ltstring dataUsingEncoding:NSUTF8StringEncoding];
        
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat: @"yyyyMMdd_HHmmss"];
        NSString *fname = [dateFormatter stringFromDate:[NSDate date]];
        
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *strpath = [NSString stringWithFormat:@"%@/ltht%@.txt",NSHomeDirectory(),fname];
        
        bool bRet = [fm createFileAtPath:strpath contents:ltdata attributes:nil];
        
        
        ltstring = [@"" stringByAppendingFormat:@"%@",self.ltten_1.stringValue ];
        
        
        ltdata = [ltstring dataUsingEncoding:NSUTF8StringEncoding];
        
        
        strpath = [NSString stringWithFormat:@"%@/Desktop/特等奖%@.txt",NSHomeDirectory(),fname];
        bRet = [fm createFileAtPath:strpath contents:ltdata attributes:nil];
        
        
        if(!bRet){
            NSLog(@"create file error");
        }
        
        return;
    }
    else
    {
        self.btn.title =@"停止";
        startT =true;
        
        
    }
    
    if( aArrayT == nil || aArrayT.count <1)
    {
        // NSString *name =@"11,22,33,44,55,66,77,88,99,00,11,222,333,444,555,666,777,888,999,000,1,2,3,4,5,6,7,8,9,0";
        // aArrayT = [ltmodel Instantiation];// [name componentsSeparatedByString:@","];
        
        
        
        NSArray * efflist = [ltmodel geteffectivelist];
        
        int listcount = (int)efflist.count;
        
        //int agnum = (int)(((float)listcount/3) + 0.4);
        
        //int add = listcount%10;
        
         for (int i = 0; i < listcount; i++) {
            
//            if(aArrayT.count < agnum)
//            {
                [aArrayT addObject:efflist[i]];
                
//            }
            
            
        }
        
        
        
        
        indexnumT =0;
    }
    
    
    
    //    for(NSString *s in aArrayT)
    //    {
    //        //self.ltten_one.stringValue = s;
    //        [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:2];
    //    }
    
    [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:0.05];
    
    
    
    
}

- (void)setlabvale:(NSString*) val {
    
    if(!startT)
    {
        return;
    }
    
    
    self.ltten_1.stringValue =  ((ltmodel*)aArrayT[indexnumT]).name;
    
    
    indexnumT++;
    
    if(indexnumT >= aArrayT.count)
    {
        indexnumT = 0;
    }
    
    [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:0.05];
    // Update the view, if already loaded.
}



- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    
    // Update the view, if already loaded.
}



- (void)txtTimeLabel: (NSTextField*)txtfield
{
    
    
    NSRect textFieldFrame = [txtfield frame];
    
    CGFloat centerX = textFieldFrame.origin.x;
    CGFloat centerY = textFieldFrame.origin.y;
    
    CABasicAnimation *animation = [[CABasicAnimation alloc] init];
    animation.keyPath = @"position";
    animation.duration = 0.08;
    animation.repeatCount = 2;
    animation.autoreverses = true;
    
    NSPoint one = NSMakePoint(centerX, centerY-2);
    NSPoint two = NSMakePoint(centerX, centerY+2);
    
    animation.fromValue = [NSValue valueWithPoint:one];
    animation.toValue = [NSValue valueWithPoint:two];
    
    [txtfield.layer addAnimation:animation forKey:@"position"];
}


@end
