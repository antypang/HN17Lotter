//
//  ViewController.h
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//
 
#import <QuartzCore/CAAnimation.h>
#import <Cocoa/Cocoa.h>
 

@interface ViewControllerT : NSViewController <CAAnimationDelegate>



@property (weak) IBOutlet NSTextField *ltten_1;
 


@property (weak) IBOutlet NSButton *btn;

 @property (weak) IBOutlet NSButton *lthdbtn;

@end

