//
//  ViewController.h
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//

#import <Cocoa/Cocoa.h>
//@class ViewController;//, CustomTableViewController, CustomImageViewController;
#import "ViewController.h"
#import "ViewController4.h"

#import "ViewController3.h"

#import "ViewController2.h"
#import "ViewController1.h"
#import "ViewControllerT.h"
#import "ViewControllerP.h"





@interface ViewControllermain : NSViewController <NSTextFieldDelegate>

@property (weak) IBOutlet NSView *myTargetView;

@property (nonatomic, assign) NSViewController *myCurrentViewController;

@property (nonatomic, strong) ViewController *ViewController1;

@property (nonatomic, strong) ViewController *ViewController2;


@property (nonatomic, strong) ViewController *ViewController3;


@property (nonatomic, strong) ViewController *ViewController4;


@property (nonatomic, strong) ViewController *ViewController5;



@property (nonatomic, strong) ViewController4 *ViewController41;
@property (nonatomic, strong) ViewController3 *ViewController31;

@property (nonatomic, strong) ViewController2 *ViewController21;

@property (nonatomic, strong) ViewController2 *ViewController11;

@property (nonatomic, strong) ViewControllerT *ViewControllerT;

@property (nonatomic, strong) ViewControllerP *ViewControllerP;


@property (weak) IBOutlet NSSegmentedControl *fiveltswith;



@property (weak) IBOutlet NSButton *btn;



@end

