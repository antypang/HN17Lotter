//
//  ViewController.m
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//

#import "ViewController3.h"
#import <QuartzCore/CAAnimation.h>

#import "NSTextFieldPlus.h"

#import "ltmodel.h"


@implementation ViewController3

int indexnum31;
NSMutableArray *aArray31 ;
NSMutableArray *aArray312 ;
NSMutableArray *aArray313;
NSMutableArray *aArray314 ;

NSMutableArray *aArray319 ;


bool start31;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    start31 = false;
    
    
    aArray31 = [[NSMutableArray alloc] init];
    aArray312 = [[NSMutableArray alloc] init];
    aArray313 = [[NSMutableArray alloc] init];
    aArray314 = [[NSMutableArray alloc] init];
    
    aArray319 = [[NSMutableArray alloc] init];
    
    
    
    
    NSInteger txtheight = 28;
    
    CGRect rect = self.ltten_1.frame;
    rect.size.height = txtheight;
    self.ltten_1.frame = rect;
    self.ltten_1.enabled = false;
    
    CGRect rect2 = self.ltten_2.frame;
    rect2.size.height = txtheight;
    self.ltten_2.frame = rect2;
    self.ltten_2.enabled = false;
    
    CGRect rect3 = self.ltten_3.frame;
    rect3.size.height = txtheight;
    self.ltten_3.frame = rect3;
    self.ltten_3.enabled = false;
    
    CGRect rect4 = self.ltten_4.frame;
    rect4.size.height = txtheight;
    self.ltten_4.frame = rect4;
    self.ltten_4.enabled = false;
    
    
    CGRect rect9 = self.ltten_9.frame;
    rect9.size.height = txtheight;
    self.ltten_9.frame = rect9;
    self.ltten_9.enabled = false;
    
    
    
    txtheight = 42;
    
    CGRect rect1 = self.btn.frame;
    rect1.size.height = txtheight;
    self.btn.frame = rect1;
    
    [ltmodel randomnumltlist];

    // Do any additional setup after loading the view.
}
- (void)controlTextDidChange:(NSNotification *)notification
{
    [self txtTimeLabel:[notification object]];
    
}

//- (void)textDidChange:(NSNotification *)notification
//{
//
//}

- (IBAction)testbtn:(id)sender {
    
    
    
    
    if(start31)
    {
        self.btn.enabled =false;
        self.btn.title =@"本次已抽完";
        start31 = false;
        
        
        [ltmodel updateltmodel:self.ltten_1.stringValue State:3];
        [ltmodel updateltmodel:self.ltten_2.stringValue State:3];
        [ltmodel updateltmodel:self.ltten_3.stringValue State:3];
        [ltmodel updateltmodel:self.ltten_4.stringValue State:3];
        
        [ltmodel updateltmodel:self.ltten_9.stringValue State:4];
        
        
        NSString *ltstring = @"";
        
        for(ltmodel *_l in [ltmodel Instantiation] )
        {
            ltstring = [ ltstring stringByAppendingFormat:@"%@|%d,",_l.name,_l.state];
        }
        
        // [[ltmodel Instantiation] componentsJoinedByString:@","];
        NSData* ltdata = [ltstring dataUsingEncoding:NSUTF8StringEncoding];
        
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat: @"yyyyMMdd_HHmmss"];
        NSString *fname = [dateFormatter stringFromDate:[NSDate date]];
        
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *strpath = [NSString stringWithFormat:@"%@/ltht%@.txt",NSHomeDirectory(),fname];
        
        bool bRet = [fm createFileAtPath:strpath contents:ltdata attributes:nil];
        
        
        ltstring = [@"" stringByAppendingFormat:@"%@\n%@\n%@\n%@\n%@",self.ltten_1.stringValue,self.ltten_2.stringValue,self.ltten_3.stringValue,self.ltten_4.stringValue,self.ltten_9.stringValue ];
        
        
        ltdata = [ltstring dataUsingEncoding:NSUTF8StringEncoding];
        
        
        strpath = [NSString stringWithFormat:@"%@/Desktop/三等奖%@.txt",NSHomeDirectory(),fname];
        bRet = [fm createFileAtPath:strpath contents:ltdata attributes:nil];
        
        
        if(!bRet){
            NSLog(@"create file error");
        }
        
        return;
    }
    else
    {
        self.btn.title =@"停止";
        start31 =true;
        
        
    }
    
    if( aArray31 == nil || aArray31.count <1)
    {
        // NSString *name =@"11,22,33,44,55,66,77,88,99,00,11,222,333,444,555,666,777,888,999,000,1,2,3,4,5,6,7,8,9,0";
        // aArray31 = [ltmodel Instantiation];// [name componentsSeparatedByString:@","];
        
        
        
        NSArray * efflist = [ltmodel geteffectivelist];
        
        int listcount = (int)efflist.count;
        
        int agnum = (int)(((float)listcount/5) + 0.4);
        
        //int add = listcount%10;
        
        
        for (int i = 0; i < listcount; i++) {
            
            if(aArray31.count < agnum)
            {
                [aArray31 addObject:efflist[i]];
                
            }
            else if(aArray312.count < agnum)
            {
                [aArray312 addObject:efflist[i]];
                
            }
            else if(aArray313.count < agnum)
            {
                [aArray313 addObject:efflist[i]];
                
            }
            else if(aArray314.count < agnum)
            {
                [aArray314 addObject:efflist[i]];
                
            }
            
            else
            {
                [aArray319 addObject:efflist[i]];
                
            }
            
        }
        
        
        
        
        indexnum31 =0;
    }
    
    
    
    //    for(NSString *s in aArray31)
    //    {
    //        //self.ltten_one.stringValue = s;
    //        [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:2];
    //    }
    
    [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:0.05];
    
    
    
    
}

- (void)setlabvale:(NSString*) val {
    
    if(!start31)
    {
        return;
    }
    
    int indext31 = indexnum31;
    
    self.ltten_1.stringValue =  ((ltmodel*)aArray31[indexnum31]).name;
    self.ltten_2.stringValue =  ((ltmodel*)aArray312[indexnum31]).name;
    self.ltten_3.stringValue =  ((ltmodel*)aArray313[indexnum31]).name;
    self.ltten_4.stringValue =  ((ltmodel*)aArray314[indexnum31]).name;
    
    
    if(indexnum31 >= aArray319.count)
    {
        indext31 = (int)aArray319.count - 1;
    }
    
    self.ltten_9.stringValue = ((ltmodel*)aArray319[indext31]).name;
    
    
    
    indexnum31++;
    
    if(indexnum31 >= aArray31.count)
    {
        indexnum31 = 0;
    }
    
    [self performSelector:@selector(setlabvale:) withObject:nil afterDelay:0.05];
    // Update the view, if already loaded.
}



- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    
    // Update the view, if already loaded.
}




- (void)txtTimeLabel: (NSTextField*)txtfield
{
    
    
    NSRect textFieldFrame = [txtfield frame];
    
    CGFloat centerX = textFieldFrame.origin.x;
    CGFloat centerY = textFieldFrame.origin.y;
    
    CABasicAnimation *animation = [[CABasicAnimation alloc] init];
    animation.keyPath = @"position";
    animation.duration = 0.08;
    animation.repeatCount = 2;
    animation.autoreverses = true;
    
    NSPoint one = NSMakePoint(centerX, centerY-2);
    NSPoint two = NSMakePoint(centerX, centerY+2);
    
    animation.fromValue = [NSValue valueWithPoint:one];
    animation.toValue = [NSValue valueWithPoint:two];
    
    [txtfield.layer addAnimation:animation forKey:@"position"];
}


@end
