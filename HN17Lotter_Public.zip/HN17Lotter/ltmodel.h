//
//  ViewController.h
//  HN17Lotter
//
//  Created by CITS-Antie on 17/1/18.
//  Copyright © 2017年 ChounFeng. All rights reserved.
//
#import <Cocoa/Cocoa.h>

 
@interface ltmodel : NSObject


@property int ordernum;
@property float randomnum;

 @property (nonatomic, copy) NSString *name;

@property int state;


+ (NSMutableArray *)Instantiation;

+ (NSArray*) geteffectivelist;

+ (void)updateltmodel:(NSString *)name State:(int)state;

+ (NSArray*) getPluslist;
+ (void) randomnumltlist;

@end

